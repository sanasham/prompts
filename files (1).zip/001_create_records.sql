-- ─────────────────────────────────────────────────────────────────────────────
-- Migration: create records table with upsert support
-- Adapt column names / types to match your 122 actual fields.
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS records (
    id            BIGSERIAL PRIMARY KEY,
    external_id   VARCHAR(255) NOT NULL UNIQUE,  -- <-- conflict key (DB_UNIQUE_KEY)

    -- Add your 122 actual business columns here, e.g.:
    -- name          TEXT,
    -- email         TEXT,
    -- phone         VARCHAR(50),
    -- status        VARCHAR(50),
    -- ...

    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index on the unique key for fast conflict detection
CREATE UNIQUE INDEX IF NOT EXISTS idx_records_external_id ON records (external_id);

-- Optional: index frequently queried columns
-- CREATE INDEX IF NOT EXISTS idx_records_status ON records (status);
