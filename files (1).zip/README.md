# Excel Bulk Upsert API

Production-ready Node.js API for processing 50,000+ row Excel files (122 fields each) inside a memory-constrained pod (1.6 GB).

---

## Architecture

```
Client ──POST /api/upload──▶ Express API
                                  │
                        multer streams file to disk
                                  │
                         jobStore.create(jobId)
                                  │
                        jobQueue.add(jobId) ──▶ BullMQ (Redis)
                                  │
                    ◀── 202 { jobId, statusUrl } ────────────────
                                  
                         (async, in background)
                                  
BullMQ Worker ──────▶ parseExcelStream (ExcelJS streaming reader)
                              │
                    yields chunk[] (500 rows) at a time
                              │
                      bulkUpsert(chunk)
                              │
               INSERT ... ON CONFLICT DO UPDATE (Postgres)
                              │
                       jobStore.update(progress)
                              
Client ──GET /api/jobs/:jobId──▶ Poll for status & final result
```

---

## Why This Design Solves Your Problem

| Problem | Solution |
|---|---|
| Timeout errors | Return `jobId` instantly (202), process async via BullMQ |
| 1.6 GB pod OOM | ExcelJS streaming reader — only one chunk in memory at a time |
| 50K × 122 row-by-row slowness | Bulk SQL upsert: 500 rows → 1 DB round-trip |
| No progress visibility | Live progress via `GET /api/jobs/:jobId` |
| Failures mid-batch | BullMQ retry + per-chunk error isolation |

---

## Memory Footprint

| Component | Approx. Memory |
|---|---|
| Node.js runtime | ~80 MB |
| ExcelJS chunk (500 rows × 122 fields) | ~15–20 MB |
| DB pool (10 connections) | ~50 MB |
| BullMQ/Redis client | ~20 MB |
| Headroom / OS | ~200 MB |
| **Total** | **< 400 MB** — well within 1.6 GB |

The full 50K rows are **never loaded into memory simultaneously**.

---

## Setup

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
# Edit .env with your DB and Redis credentials
```

### 3. Run database migration

```bash
psql -U postgres -d mydb -f db/001_create_records.sql
```

### 4. Start Redis (if local)

```bash
docker run -d -p 6379:6379 redis:7-alpine
```

### 5. Start the API

```bash
npm start
# or for development:
npm run dev
```

---

## API Reference

### POST `/api/upload`

Upload an Excel/CSV file for async processing.

**Request:** `multipart/form-data`

| Field | Type | Description |
|---|---|---|
| `file` | File | `.xlsx`, `.xls`, or `.csv` |
| `chunkSize` | number (optional) | Rows per DB batch (default: `500`) |

**Response `202`:**
```json
{
  "jobId": "uuid-here",
  "message": "File accepted. Processing started.",
  "statusUrl": "/api/jobs/uuid-here"
}
```

---

### GET `/api/jobs/:jobId`

Poll for job status.

**Response — in progress:**
```json
{
  "jobId": "uuid-here",
  "status": "processing",
  "progress": {
    "processed": 5000,
    "created": 3200,
    "updated": 1800,
    "failed": 0
  }
}
```

**Response — completed:**
```json
{
  "jobId": "uuid-here",
  "status": "completed",
  "result": {
    "totalProcessed": 50000,
    "totalCreated": 32000,
    "totalUpdated": 18000,
    "totalFailed": 0,
    "message": "Processing complete. Created: 32000, Updated: 18000, Failed: 0."
  },
  "errors": []
}
```

---

### GET `/api/jobs`

List all jobs.

---

## Configuration

### Adapting to your schema

Edit `src/services/dbService.js`:

```js
const TABLE_NAME = 'your_table_name';
const UNIQUE_KEY = 'your_unique_column'; // column used for conflict detection
```

Or set via environment variables:
```
DB_TABLE=your_table
DB_UNIQUE_KEY=your_unique_col
```

### MySQL / MongoDB

The `bulkUpsert` function in `src/services/dbService.js` is self-contained.
Replace the Postgres `INSERT ... ON CONFLICT` query with:

**MySQL:**
```sql
INSERT INTO records (col1, col2) VALUES (?, ?) ...
ON DUPLICATE KEY UPDATE col1=VALUES(col1), col2=VALUES(col2), updated_at=NOW()
```

**MongoDB:**
```js
await collection.bulkWrite(rows.map(row => ({
  updateOne: {
    filter: { externalId: row.external_id },
    update: { $set: row, $setOnInsert: { createdAt: new Date() } },
    upsert: true,
  }
})));
```

---

## Tuning for Your Pod

```
NODE_OPTIONS=--max-old-space-size=1200   # Keep Node heap < 1.2 GB
DB_POOL_MAX=10                            # Don't over-allocate DB connections
chunkSize=500                             # Lower if memory tight; higher for speed
Worker concurrency=2                      # Jobs processed in parallel
```

---

## Production Checklist

- [ ] Replace in-memory `jobStore` with Redis store for multi-pod deployment
- [ ] Add authentication middleware to `/api/upload`
- [ ] Set `REDIS_PASSWORD` in production
- [ ] Configure Kubernetes `resources.limits.memory: 1.6Gi`
- [ ] Add `readinessProbe` and `livenessProbe` on `/health`
- [ ] Mount `/app/tmp` to an emptyDir or PVC (not in-container FS)
- [ ] Set up BullMQ dashboard (Bull Board) for job monitoring
- [ ] Add Prometheus metrics (`prom-client`) on job throughput

---

## Adding Bull Board (Job Monitoring UI)

```bash
npm install @bull-board/express @bull-board/api
```

```js
// In app.js
const { createBullBoard } = require('@bull-board/api');
const { BullMQAdapter } = require('@bull-board/api/bullMQAdapter');
const { ExpressAdapter } = require('@bull-board/express');

const serverAdapter = new ExpressAdapter();
createBullBoard({ queues: [new BullMQAdapter(jobQueue)], serverAdapter });
serverAdapter.setBasePath('/admin/queues');
app.use('/admin/queues', serverAdapter.getRouter());
```
