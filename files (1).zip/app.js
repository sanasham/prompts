'use strict';

const express = require('express');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { jobQueue } = require('./queue/jobQueue');
const { jobStore } = require('./store/jobStore');
const logger = require('./utils/logger');

const app = express();
app.use(express.json());

// ── Multer: stream to disk, never into memory ──────────────────────────────
const upload = multer({
  dest: path.join(__dirname, '../tmp/uploads'),
  limits: { fileSize: 200 * 1024 * 1024 }, // 200 MB max upload
  fileFilter: (_req, file, cb) => {
    const allowed = ['.xlsx', '.xls', '.csv'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) cb(null, true);
    else cb(new Error('Only .xlsx, .xls, .csv files allowed'));
  },
});

// ── POST /api/upload ───────────────────────────────────────────────────────
// Returns a jobId immediately; processing happens async in the worker queue.
app.post('/api/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

    const jobId = uuidv4();
    const chunkSize = parseInt(req.body.chunkSize, 10) || 500;

    // Register job in store before queuing
    jobStore.create(jobId, {
      fileName: req.file.originalname,
      filePath: req.file.path,
      chunkSize,
    });

    // Add to worker queue (non-blocking)
    await jobQueue.add('processExcel', { jobId }, {
      attempts: 3,
      backoff: { type: 'exponential', delay: 5000 },
      removeOnComplete: false,
      removeOnFail: false,
    });

    logger.info({ jobId, file: req.file.originalname }, 'Job queued');

    return res.status(202).json({
      jobId,
      message: 'File accepted. Processing started.',
      statusUrl: `/api/jobs/${jobId}`,
    });
  } catch (err) {
    logger.error(err, 'Upload error');
    return res.status(500).json({ error: err.message });
  }
});

// ── GET /api/jobs/:jobId ───────────────────────────────────────────────────
app.get('/api/jobs/:jobId', (req, res) => {
  const job = jobStore.get(req.params.jobId);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  return res.json(job);
});

// ── GET /api/jobs ──────────────────────────────────────────────────────────
app.get('/api/jobs', (_req, res) => {
  return res.json(jobStore.list());
});

// ── Health check ───────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok' }));

// ── Error handler ──────────────────────────────────────────────────────────
app.use((err, _req, res, _next) => {
  logger.error(err, 'Unhandled error');
  res.status(500).json({ error: err.message });
});

module.exports = app;
