'use strict';

/**
 * Bulk upsert service using PostgreSQL's INSERT ... ON CONFLICT DO UPDATE.
 * This performs one round-trip per chunk instead of one per row.
 *
 * Swap the Postgres implementation below with your ORM/driver of choice.
 * MySQL equivalent: INSERT INTO ... ON DUPLICATE KEY UPDATE
 * MongoDB equivalent: bulkWrite with upsert:true
 */

const { getPool } = require('../db/pool');
const logger = require('../utils/logger');

// ─────────────────────────────────────────────────────────────────────────────
// CONFIGURATION — edit these to match your schema
// ─────────────────────────────────────────────────────────────────────────────
const TABLE_NAME = process.env.DB_TABLE || 'records';
const UNIQUE_KEY = process.env.DB_UNIQUE_KEY || 'external_id'; // conflict column
const BATCH_SIZE = 100; // sub-batch for single SQL statement (Postgres limit safety)

/**
 * Upsert a chunk of rows.
 * @param {object[]} rows
 * @returns {{ created: number, updated: number, failed: number, chunkErrors: object[] }}
 */
async function bulkUpsert(rows) {
  if (!rows || rows.length === 0) return { created: 0, updated: 0, failed: 0, chunkErrors: [] };

  const pool = getPool();
  let created = 0;
  let updated = 0;
  let failed = 0;
  const chunkErrors = [];

  // Split into sub-batches to keep query size reasonable
  for (let i = 0; i < rows.length; i += BATCH_SIZE) {
    const batch = rows.slice(i, i + BATCH_SIZE);
    try {
      const result = await upsertBatch(pool, batch);
      created += result.created;
      updated += result.updated;
    } catch (err) {
      logger.error({ err: err.message, batchStart: i }, 'Sub-batch upsert failed');
      failed += batch.length;
      chunkErrors.push({ batchStart: i, message: err.message });
    }
  }

  return { created, updated, failed, chunkErrors };
}

/**
 * Build and execute a single multi-row INSERT ... ON CONFLICT upsert.
 */
async function upsertBatch(pool, rows) {
  if (rows.length === 0) return { created: 0, updated: 0 };

  // Derive columns from the first row (all rows must have same shape after parsing)
  const columns = Object.keys(rows[0]).filter((c) => c && c.trim());

  if (!columns.includes(UNIQUE_KEY)) {
    throw new Error(`Unique key "${UNIQUE_KEY}" not found in data columns: ${columns.join(', ')}`);
  }

  // Build parameterised query
  // INSERT INTO table (col1, col2, ...) VALUES ($1,$2,...),($N+1,$N+2,...) ...
  // ON CONFLICT (unique_key) DO UPDATE SET col1=EXCLUDED.col1, ...
  // RETURNING (xmax = 0) AS is_insert
  const colList = columns.map((c) => `"${c}"`).join(', ');
  const updateSet = columns
    .filter((c) => c !== UNIQUE_KEY)
    .map((c) => `"${c}" = EXCLUDED."${c}"`)
    .join(', ');

  const valuePlaceholders = [];
  const flatValues = [];
  let paramIdx = 1;

  for (const row of rows) {
    const rowPlaceholders = columns.map(() => `$${paramIdx++}`);
    valuePlaceholders.push(`(${rowPlaceholders.join(', ')})`);
    columns.forEach((col) => flatValues.push(row[col] ?? null));
  }

  const sql = `
    INSERT INTO "${TABLE_NAME}" (${colList})
    VALUES ${valuePlaceholders.join(', ')}
    ON CONFLICT ("${UNIQUE_KEY}") DO UPDATE
    SET ${updateSet},
        "updated_at" = NOW()
    RETURNING (xmax = 0) AS is_insert
  `;

  const { rows: resultRows } = await pool.query(sql, flatValues);

  const created = resultRows.filter((r) => r.is_insert).length;
  const updated = resultRows.length - created;

  return { created, updated };
}

module.exports = { bulkUpsert };
