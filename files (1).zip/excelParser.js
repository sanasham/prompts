'use strict';

/**
 * Streams an Excel file row-by-row using ExcelJS's streaming reader.
 * This avoids loading all 50K × 122 fields into memory at once.
 *
 * Yields arrays (chunks) of plain objects keyed by header name.
 */

const ExcelJS = require('exceljs');
const fs = require('fs');
const csv = require('csv-parser');
const path = require('path');
const logger = require('../utils/logger');

/**
 * @param {string} filePath  Path to .xlsx / .xls / .csv file on disk
 * @param {number} chunkSize Number of rows per yielded batch
 * @yields {object[]}        Batch of row objects
 */
async function* parseExcelStream(filePath, chunkSize = 500) {
  const ext = path.extname(filePath).toLowerCase();

  if (ext === '.csv') {
    yield* parseCsvStream(filePath, chunkSize);
  } else {
    yield* parseXlsxStream(filePath, chunkSize);
  }
}

async function* parseXlsxStream(filePath, chunkSize) {
  const workbook = new ExcelJS.stream.xlsx.WorkbookReader(filePath, {
    sharedStrings: 'cache',   // required for shared strings
    hyperlinks: 'ignore',
    styles: 'ignore',
    entries: 'emit',
    worksheets: 'emit',
  });

  let headers = null;
  let chunk = [];

  for await (const worksheetReader of workbook) {
    // Only process the first sheet
    for await (const row of worksheetReader) {
      if (row.number === 1) {
        // Extract headers from first row
        headers = [];
        row.eachCell({ includeEmpty: true }, (cell, colNum) => {
          headers[colNum - 1] = String(cell.value || `col_${colNum}`).trim();
        });
        continue;
      }

      if (!headers) continue;

      const record = {};
      row.eachCell({ includeEmpty: true }, (cell, colNum) => {
        const header = headers[colNum - 1];
        if (header) record[header] = sanitizeCellValue(cell.value);
      });

      // Skip completely empty rows
      if (Object.values(record).some((v) => v !== null && v !== '')) {
        chunk.push(record);
      }

      if (chunk.length >= chunkSize) {
        yield chunk;
        chunk = []; // Release memory immediately
      }
    }
    break; // Only first worksheet
  }

  if (chunk.length > 0) yield chunk;
}

async function* parseCsvStream(filePath, chunkSize) {
  let chunk = [];

  await new Promise((resolve, reject) => {
    const stream = fs.createReadStream(filePath)
      .pipe(csv())
      .on('data', (row) => {
        chunk.push(row);
        if (chunk.length >= chunkSize) {
          stream.pause();
        }
      })
      .on('end', resolve)
      .on('error', reject);
  });

  // For simplicity with CSV, yield pre-collected chunks
  // For truly massive CSVs consider a generator-friendly csv lib
  while (chunk.length > 0) {
    yield chunk.splice(0, chunkSize);
  }
}

/**
 * Normalise ExcelJS cell values (handles Date, RichText, formula results, etc.)
 */
function sanitizeCellValue(value) {
  if (value === null || value === undefined) return null;
  if (value instanceof Date) return value.toISOString();
  if (typeof value === 'object') {
    // RichText
    if (Array.isArray(value?.richText)) {
      return value.richText.map((rt) => rt.text || '').join('');
    }
    // Formula result
    if (value?.result !== undefined) return sanitizeCellValue(value.result);
    // Hyperlink
    if (value?.text !== undefined) return String(value.text);
  }
  return value;
}

module.exports = { parseExcelStream };
