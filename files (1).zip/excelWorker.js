'use strict';

const { Worker } = require('bullmq');
const { connection } = require('../queue/jobQueue');
const { jobStore } = require('../store/jobStore');
const { parseExcelStream } = require('../services/excelParser');
const { bulkUpsert } = require('../services/dbService');
const logger = require('../utils/logger');
const fs = require('fs');

const worker = new Worker(
  'excelProcessing',
  async (job) => {
    const { jobId } = job.data;
    const meta = jobStore.get(jobId);

    if (!meta) throw new Error(`Job metadata not found for jobId=${jobId}`);

    jobStore.update(jobId, { status: 'processing', startedAt: new Date() });
    logger.info({ jobId }, 'Worker started processing');

    let totalCreated = 0;
    let totalUpdated = 0;
    let totalFailed = 0;
    let totalProcessed = 0;
    const errors = [];

    try {
      // Stream-parse Excel, yielding chunks to avoid memory blowup
      for await (const chunk of parseExcelStream(meta.filePath, meta.chunkSize)) {
        try {
          const { created, updated, failed, chunkErrors } = await bulkUpsert(chunk);
          totalCreated += created;
          totalUpdated += updated;
          totalFailed += failed;
          totalProcessed += chunk.length;

          if (chunkErrors.length) errors.push(...chunkErrors.slice(0, 10)); // cap stored errors

          // Update progress
          jobStore.update(jobId, {
            progress: {
              processed: totalProcessed,
              created: totalCreated,
              updated: totalUpdated,
              failed: totalFailed,
            },
          });

          logger.info({ jobId, totalProcessed, created, updated, failed }, 'Chunk upserted');
        } catch (chunkErr) {
          logger.error({ jobId, err: chunkErr.message }, 'Chunk upsert failed');
          errors.push({ message: chunkErr.message });
          totalFailed += chunk.length;
        }
      }

      // Cleanup temp file
      try { fs.unlinkSync(meta.filePath); } catch (_) {}

      jobStore.update(jobId, {
        status: 'completed',
        completedAt: new Date(),
        result: {
          totalProcessed,
          totalCreated,
          totalUpdated,
          totalFailed,
          message: `Processing complete. Created: ${totalCreated}, Updated: ${totalUpdated}, Failed: ${totalFailed}.`,
        },
        errors: errors.slice(0, 50),
      });

      logger.info({ jobId, totalCreated, totalUpdated, totalFailed }, 'Job completed');
    } catch (err) {
      try { fs.unlinkSync(meta.filePath); } catch (_) {}
      jobStore.update(jobId, {
        status: 'failed',
        error: err.message,
        completedAt: new Date(),
      });
      throw err; // Let BullMQ retry
    }
  },
  {
    connection,
    concurrency: 2, // Process 2 jobs simultaneously (tune based on DB pool)
    limiter: { max: 2, duration: 1000 },
  }
);

worker.on('completed', (job) => logger.info({ jobId: job.data.jobId }, 'Worker job completed'));
worker.on('failed', (job, err) => logger.error({ jobId: job?.data?.jobId, err: err.message }, 'Worker job failed'));

module.exports = worker;
