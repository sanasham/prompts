'use strict';

/**
 * Simple in-memory job store.
 *
 * ⚠️  For multi-pod / production use, replace with a Redis-backed store:
 *     const redis = require('ioredis'); client.set(jobId, JSON.stringify(data), 'EX', 86400);
 */

const store = new Map();

const jobStore = {
  create(jobId, meta) {
    store.set(jobId, {
      jobId,
      status: 'queued',
      createdAt: new Date(),
      startedAt: null,
      completedAt: null,
      progress: { processed: 0, created: 0, updated: 0, failed: 0 },
      result: null,
      errors: [],
      ...meta,
    });
  },

  get(jobId) {
    return store.get(jobId) || null;
  },

  update(jobId, patch) {
    const existing = store.get(jobId);
    if (!existing) return;
    store.set(jobId, { ...existing, ...patch });
  },

  list() {
    return [...store.values()].map(({ filePath, ...safe }) => safe); // strip disk path
  },

  delete(jobId) {
    store.delete(jobId);
  },
};

module.exports = { jobStore };
